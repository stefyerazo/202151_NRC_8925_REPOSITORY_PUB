
package pilas;


public class ProductosRopa {
    private int codigo;
    private String nombre;
    private int talla;
    private double precio;
    private boolean descuento;
    private double precioFinal;
    
    //Constructor
    public ProductosRopa(int codigo, String nombre, int talla, double precio, boolean descuento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.talla = talla;
        this.precio = precio;
        this.descuento = descuento;
    }
    
    //CONSTRUCTOR VACÍO
     public ProductosRopa() {
        this.codigo = 0;
        this.nombre = null;
        this.talla = 0;
        this.precio = 0.0;
        
    }
     
     public void calcularPrecio(){
        //double valDescuento;
        if (descuento==true){
            precioFinal=precio-precio*20/100;
        }else{
            precioFinal=precio;
        }
    }

    @Override
    public String toString() {
        return "Producto Ropa\n{"
                + "Código=" + codigo + ", Nombre=" + nombre + ", Talla=" + talla 
                + ", Precio=" + precio + ", PrecioFinal=" + precioFinal + '}';
    }
}
