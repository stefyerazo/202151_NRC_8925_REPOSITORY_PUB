
package pilas;

import java.util.Scanner;
import javax.swing.JOptionPane;


public class principal {

    
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
//Crear objetos de las clases
        ProductosCocina cocina;
        ProductosLimpieza limpieza;
        ProductosRopa ropa;
//Variables para ingresar datos en pilas
        int codigo;
        String nombre;
        double precio;
        boolean descuento;
        int talla;
        double precioFinal;
        int opcDescuento;
        /*
        ********************************************
                   MENÚ PRODUCTO PILA
        ********************************************
        */
       
        System.out.println("**********************************************"); 
       System.out.println("Bienvenido a Menú Pila de Productos TIPO PILA");
        System.out.println("**********************************************");
        System.out.println("");
        int opcMenu, menuPilaCocina, menuPilaLimpieza, menuPilaRopa; 
        int cantCocina, cantLimpieza, cantRopa ;
        try{
        do{
        System.out.println("Elija uno de los siguientes Submenús:\n"
                + "   1.- Productos de Cocina\n"
                + "   2.- Productos de Limpieza\n"
                + "   3.- Productos de Ropa");
        opcMenu = sc.nextInt();
        switch (opcMenu){
            case 1:
                System.out.println("--> BIENVENIDO PILA PRODUCTOS DE COCINA <--");
                System.out.print("Seleccione cuantos elementos de cocina desea tener en su pila:");
                cantCocina=sc.nextInt();
                PilaCocina oPilaCoc = new PilaCocina(cantCocina);
                do{
                System.out.println("\nIndique qué Opción desea elegir: \n"
                        + "   1.- Ingresar un producto a la Pila\n"
                        + "   2.- Sacar un elemento de la Pila\n"
                        + "   3.- Revisar último elemento colocado\n"
                        + "   4.- Tamaño de la pila\n"
                        + "   5.- Salir");
                menuPilaCocina=sc.nextInt();
                switch(menuPilaCocina){
                    case 1:
                        System.out.println(" INGRESAR UN PRODUCTO DE COCINA A LA PILA ");
                        System.out.println("Ingrese los siguientes datos: ");
                        System.out.print("Código: ");
                        codigo = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Nombre: ");
                        nombre = sc.nextLine();
                        System.out.print("Precio: ");
                        precio = sc.nextDouble();
                        System.out.print("Presione 1 si existe descuento, caso contrario presione otra tecla: ");
                        sc.nextLine();
                        opcDescuento = sc.nextInt();
                        if(opcDescuento == 1){
                            descuento=true;
                        }else{
                            descuento=false;
                        }
                        cocina = new ProductosCocina(codigo, nombre, precio, descuento);
                        cocina.calcularPrecio();
                        if (!oPilaCoc.estaLlena()) {
                            oPilaCoc.push(cocina);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta llena", "Pila Llena", 
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    
                    case 2:
                        System.out.println(" SE RETIRARÁ EL ÚLTIMO ELEMENTO DE LA PILA ");
                        if (!oPilaCoc.estaVacia()) {
                            JOptionPane.showMessageDialog(null, "El producto sacado es:\n"
                                    +oPilaCoc.pop().toString(), "Obteniendo datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                        
                    case 3:
                        System.out.println(" SE MUESTRA EL ÚLTIMO ELEMENTO COLOCADO EN LA PILA:");
                        if (!oPilaCoc.estaVacia()) {
                            JOptionPane.showMessageDialog(null, "El rpoducto que esta en la CIMA es:"
                                    + oPilaCoc.cimaPila().toString(), "Producto de la Cima", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia ", JOptionPane.INFORMATION_MESSAGE);

                        }
                        break;
                        
                    case 4: 
                        System.out.println("SE VERIFICA EL TAMAÑO DE LA PILA");
                        System.out.println("El tamaño de la Pila es: "+oPilaCoc.tamanioPila());
                        break;
                    
                    default:
                    System.out.println("Indique la opción correcta");    
                }
                }while(menuPilaCocina != 5);
                
                break;
                
            case 2:
                System.out.println("--> BIENVENIDO PILA PRODUCTOS DE LIMPIEZA <--");
                System.out.print("Seleccione cuantos elementos de limpieza desea tener en su pila:");
                cantLimpieza=sc.nextInt();
                PilaLimpieza oPilaLim = new PilaLimpieza(cantLimpieza);
                do{
                System.out.println("\nIndique qué Opción desea elegir: \n"
                        + "   1.- Ingresar un producto a la Pila\n"
                        + "   2.- Sacar un elemento de la Pila\n"
                        + "   3.- Revisar último elemento colocado\n"
                        + "   4.- Tamaño de la pila\n"
                        + "   5.- Salir");
                menuPilaLimpieza=sc.nextInt();
                switch(menuPilaLimpieza){
                    case 1:
                        System.out.println(" INGRESAR UN PRODUCTO DE LIMPIEZA A LA PILA ");
                        System.out.println("Ingrese los siguientes datos: ");
                        System.out.print("Código: ");
                        codigo = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Nombre: ");
                        nombre = sc.nextLine();
                        System.out.print("Precio: ");
                        precio = sc.nextDouble();
                        System.out.print("Presione 1 si existe descuento, caso contrario presione otra tecla: ");
                        sc.nextLine();
                        opcDescuento = sc.nextInt();
                        if(opcDescuento == 1){
                            descuento=true;
                        }else{
                            descuento=false;
                        }
                        //CREACIÓN DE OBJETO
                        limpieza = new ProductosLimpieza(codigo, nombre, precio, descuento);
                        limpieza.calcularPrecio();
                        if (!oPilaLim.estaLlena()) {
                            oPilaLim.push(limpieza);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta llena", "Pila Llena", 
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    
                    case 2:
                        System.out.println(" SE RETIRARÁ EL ÚLTIMO ELEMENTO DE LA PILA ");
                        if (!oPilaLim.estaVacia()) {
                            JOptionPane.showMessageDialog(null, "El producto sacado es:\n"
                                    +oPilaLim.pop().toString(), "Obteniendo datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                        
                    case 3:
                        System.out.println(" SE MUESTRA EL ÚLTIMO ELEMENTO COLOCADO EN LA PILA:");
                        if (!oPilaLim.estaVacia()) {
                            JOptionPane.showMessageDialog(null, "El producto que esta en la CIMA es:"
                                    + oPilaLim.cimaPila().toString(), "Producto de la Cima", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia ", JOptionPane.INFORMATION_MESSAGE);

                        }
                        break;
                        
                    case 4: 
                        System.out.println("SE VERIFICA EL TAMAÑO DE LA PILA");
                        System.out.println("El tamaño de la Pila es: "+oPilaLim.tamanioPila());
                        break;
                    
                    default:
                    System.out.println("Indique la opción correcta");    
                }
                }while(menuPilaLimpieza != 5);
                
                break;
                
            case 3:
                System.out.println("--> BIENVENIDO PILA ROPA <--");
                System.out.print("Seleccione cuantos elementos de ropa desea tener en su pila:");
                cantRopa=sc.nextInt();
                PilaRopa oPilaRopa = new PilaRopa(cantRopa);
                do{
                System.out.println("\nIndique qué Opción desea elegir: \n"
                        + "   1.- Ingresar un producto a la Pila\n"
                        + "   2.- Sacar un elemento de la Pila\n"
                        + "   3.- Revisar último elemento colocado\n"
                        + "   4.- Tamaño de la pila\n"
                        + "   5.- Salir");
                menuPilaRopa=sc.nextInt();
                switch(menuPilaRopa){
                    case 1:
                        System.out.println(" INGRESAR UN PRODUCTO DE ROPA ");
                        System.out.println("Ingrese los siguientes datos: ");
                        System.out.print("Código: ");
                        codigo = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Nombre: ");
                        nombre = sc.nextLine();
                        System.out.println("Talla(entero): ");
                        talla = sc.nextInt();
                        System.out.print("Precio: ");
                        precio = sc.nextDouble();
                        System.out.print("Presione 1 si existe descuento, caso contrario presione 0: ");
                        sc.nextLine();
                        opcDescuento = sc.nextInt();
                        if(opcDescuento == 1){
                            descuento=true;
                        }else{
                            descuento=false;
                        }
                        //CREACIÓN DE OBJETO
                        ropa = new ProductosRopa(codigo, nombre, talla, precio, descuento);
                        ropa.calcularPrecio();
                        if (!oPilaRopa.estaLlena()) {
                            oPilaRopa.push(ropa);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta llena", "Pila Llena", 
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    
                    case 2:
                        System.out.println(" SE RETIRARÁ EL ÚLTIMO ELEMENTO DE LA PILA ");
                        if (!oPilaRopa.estaVacia()) {
                            JOptionPane.showMessageDialog(null, "El producto (ropa) sacado es:\n"
                                    +oPilaRopa.pop().toString(), "Obteniendo datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                        
                    case 3:
                        System.out.println(" SE MUESTRA EL ÚLTIMO ELEMENTO (ROPA) COLOCADO EN LA PILA:");
                        if (!oPilaRopa.estaVacia()) {
                            JOptionPane.showMessageDialog(null, "El producto que esta en la CIMA es:"
                                    + oPilaRopa.cimaPila().toString(), "Producto de la Cima", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "La Pila esta vacia", "Pila vacia ", JOptionPane.INFORMATION_MESSAGE);

                        }
                        break;
                        
                    case 4: 
                        System.out.println("SE VERIFICA EL TAMAÑO DE LA PILA");
                        System.out.println("El tamaño de la Pila es: "+oPilaRopa.tamanioPila());
                        break;
                    
                    default:
                    System.out.println("Indique la opción correcta");    
                }
                }while(menuPilaRopa != 5);
                
                break;
        }
        
        }while(opcMenu!=4);
        } catch (NumberFormatException n) {
            JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
        }
    }
}
