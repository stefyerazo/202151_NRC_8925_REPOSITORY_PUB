package lista.dinamica;

public class Cliente {
	
	private int cedula;
	private String nombres;
	private String apellidos;
	private String genero;
	private int celular;
	
	public Cliente(int cedula, String nombres, String apellidos, String genero, int celular) {
		super();
		this.cedula = cedula;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.genero = genero;
		this.celular = celular;
	}

	public int getCedula() {
		return cedula;
	}

	public void setCedula(int cedula) {
		this.cedula = cedula;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public int getCelular() {
		return celular;
	}

	public void setCelular(int celular) {
		this.celular = celular;
	}

	@Override
	public String toString() {
		return "\nCliente [cedula=" + cedula + ", nombres=" + nombres + ", apellidos=" + apellidos + ", genero=" + genero
				+ ", celular=" + celular + "]";
	}
	
}
