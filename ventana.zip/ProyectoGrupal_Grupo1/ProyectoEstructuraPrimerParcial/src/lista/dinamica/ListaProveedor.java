package lista.dinamica;

public class ListaProveedor {
	protected NodoProveedor inicio, fin;// Puntero de la lista

	// Constructor
	public ListaProveedor() {
		this.inicio = null;
		this.fin = null;
	}

	// Metodo para agregar un nuevo nodo Inicio Lista
	public void agregarInicioProveedor(Proveedor palabras) {
		inicio = new NodoProveedor(palabras, inicio);
		// caso particular
		if (fin == null) {
			fin = inicio;
		}
	}

	// Metodo para mostrar los datos
	public void mostrarListaProveedor() {
		NodoProveedor recorrer = inicio;
		System.out.println();
		while (recorrer != null) {
			System.out.print("[" + recorrer.dato + "]-->");
			recorrer = recorrer.siguinte;
		}
		System.out.println("NULL");
	}
	
	public Proveedor eliminarInicioPersona() {
		Proveedor elemento =inicio.dato;
		if (inicio==fin) {
			inicio=null;
			fin=null;
			//return 0;
		}else {
			inicio=inicio.siguinte;
		}
		return elemento;
	}
	
	public Proveedor eliminarFinalPersona() {
		Proveedor elemento = fin.dato;
		if (inicio==fin) {
			inicio = null;
			fin = null;
		}else {
			NodoProveedor temporal=inicio;
			while(temporal.siguinte != fin) {
				temporal = temporal.siguinte;
				
			}
			fin=temporal;
			fin.siguinte =null;
		}
		return elemento;
	}
	
	public boolean estaVacia() {
		if (this.inicio ==null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void agregarFinal(Proveedor elemento) {
		//utilizar un metodo para verificar si esta vacia
		if (!estaVacia()) {
			this.fin.siguinte = new NodoProveedor(elemento);
			this.fin = fin.siguinte;
			
		}else {
			inicio = fin = new NodoProveedor(elemento);
			
		}
	}
}
