package lista.estatica;

import java.util.Scanner;

public class ListaProductosVestimenta {
	protected NodoProductoVestimenta inicio, fin;// Puntero de la lista
	
	ListaProductosVestimenta[] listaVestimenta = new ListaProductosVestimenta[3];
	ListaProductosVestimenta ovest = null;
	
	//contador inicializado en 0
	int contador = 0; 
	private int idVestimenta; 
	private String talla;
	private String color;
	private String categoria;
	private double costoVestimenta;
	private String nombreVestimenta;
	
	public ListaProductosVestimenta(String nombreVestimenta, int idVestimenta, String talla, String color, String categoria, double costoVestimenta) {
		super();
		this.idVestimenta = idVestimenta;
		this.talla = talla;
		this.color = color;
		this.categoria = categoria;
		this.costoVestimenta = costoVestimenta;
		this.nombreVestimenta = nombreVestimenta;
	}
	
	
	public String getNombreVestimenta() {
		return nombreVestimenta;
	}


	public void setNombreVestimenta(String nombreVestimenta) {
		this.nombreVestimenta = nombreVestimenta;
	}


	public int getIdVestimenta() {
		return idVestimenta;
	}
	public void setIdVestimenta(int idVestimenta) {
		this.idVestimenta = idVestimenta;
	}
	public String getTalla() {
		return talla;
	}
	public void setTalla(String talla) {
		this.talla = talla;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public double getCostoVestimenta() {
		return costoVestimenta;
	}

	public void setCostoVestimenta(double costoVestimenta) {
		this.costoVestimenta = costoVestimenta;
	}

	
	public ListaProductosVestimenta() {
		this.inicio = null;
		this.fin = null;
	}

	// Metodo para agregar un nuevo nodo Inicio Lista
	public void agregarInicioProductosVestimenta(ProductosVestimenta palabras) {
		inicio = new NodoProductoVestimenta(palabras, inicio);
		// caso particular
		if (fin == null) {
			fin = inicio;
		}
	}

	// Metodo para mostrar los datos
	public void mostrarListaProductosAlimenticios() {
		NodoProductoVestimenta recorrer = inicio;
		System.out.println();
		while (recorrer != null) {
			System.out.print("[" + recorrer.dato + "]-->");
			recorrer = recorrer.siguinte;
		}
		System.out.println("NULL");
	}
	
	public ProductosVestimenta eliminarInicioProductosVestimentas() {
		ProductosVestimenta elemento =inicio.dato;
		if (inicio==fin) {
			inicio=null;
			fin=null;
			//return 0;
		}else {
			inicio=inicio.siguinte;
		}
		return elemento;
	}
	
	public ProductosVestimenta eliminarFinalProductoVestimenta() {
		ProductosVestimenta elemento = fin.dato;
		if (inicio==fin) {
			inicio = null;
			fin = null;
		}else {
			NodoProductoVestimenta temporal=inicio;
			while(temporal.siguinte != fin) {
				temporal = temporal.siguinte;
				
			}
			fin=temporal;
			fin.siguinte =null;
		}
		return elemento;
	}
	
	public boolean estaVacia() {
		if (this.inicio ==null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void agregarFinal(ProductosVestimenta elemento) {
		//utilizar un metodo para verificar si esta vacia
		if (!estaVacia()) {
			this.fin.siguinte = new NodoProductoVestimenta(elemento);
			this.fin = fin.siguinte;
			
		}else {
			inicio = fin = new NodoProductoVestimenta(elemento);
			
		}
	}
public ListaProductosVestimenta buscarPorNombre(String nombre) {
		
		if(!estaVacia()){
			for(int i = 0; i < listaVestimenta.length; i++) {
				if(listaVestimenta[i] != null) {
					if(listaVestimenta[i].getNombreVestimenta().equals(nombre)) {
						return listaVestimenta[i];
					}
				}
		}
			return null;
		}
		return null;
	}
	public void agregarProductoVestimenta(String nombreVestimenta, int idVestimenta, String talla, String color, String categoria, double costoVestimenta) {
		//String nombreVestimenta, int idVestimenta, String talla, String color, String categoria, double costoVestimenta
		ovest = new ListaProductosVestimenta(nombreVestimenta, idVestimenta, talla, color, categoria, costoVestimenta);
		listaVestimenta[contador] = ovest;
		contador++;	
		
	}
	public void eliminarPorNombre(String nombre) {
		
		int indice = 0;
		
		if(buscarPorNombre(nombre) != null) {
			for(int i = 0; i < listaVestimenta.length; i++) {
				 if(listaVestimenta[i] != null) {
					 if(listaVestimenta[i].getNombreVestimenta().equals(nombre)) {
							indice = i;
					}
				 }
				 
			 }
			 System.arraycopy(listaVestimenta,indice+1,listaVestimenta,indice,listaVestimenta.length-1-indice);
			 System.out.println("Elemento eliminado");
			
		}else {
			System.out.println("Elemento no existe");
		}
	}
	public void mostrarLista() {
		for(int i = 0;  i < listaVestimenta.length; i++ ){
			if(listaVestimenta[i] != null){
				System.out.println( "Nombre: " +listaVestimenta[i].getNombreVestimenta()+ " ID: " +listaVestimenta[i].getIdVestimenta()+ " Talla:  " 
						+ listaVestimenta[i].getTalla() + " Color: "+listaVestimenta[i].getColor()+ " Categoria: " + listaVestimenta[i].getCategoria() + " Costo: "+listaVestimenta[i].getCostoVestimenta()+"\n");
			}
			
		}
		
	}
	
	
	//String nombreProducto, double costoProducto, String categoria, int idProductoAseo, String descripcionAseo) {
	public void actualizarElemento(int n) {
		Scanner actu = new Scanner(System.in);
		System.out.println("Digite el nombre de la vestimenta: ");
		String nombreVestimenta = actu.next();
		System.out.println("Digite el ID de la vestimenta: ");
		int idVestimenta = actu.nextInt();
		System.out.println("Digite la Talla: ");
		String tallaVestimenta = actu.next();
		System.out.println("Digite el Color: ");
		String colorVestimenta = actu.next();
		System.out.println("Digite la Categoria: ");
		String categoriaVestimenta = actu.next();
		System.out.println("Digite el costo: ");
		double costoVestimenta = actu.nextDouble();
		
		listaVestimenta[n-1].setNombreVestimenta(nombreVestimenta);
		listaVestimenta[n-1].setIdVestimenta(idVestimenta);
		listaVestimenta[n-1].setTalla(tallaVestimenta);
		listaVestimenta[n-1].setColor(colorVestimenta);
		listaVestimenta[n-1].setCategoria(categoriaVestimenta);
		listaVestimenta[n-1].setCostoVestimenta(costoVestimenta);
	}

}
