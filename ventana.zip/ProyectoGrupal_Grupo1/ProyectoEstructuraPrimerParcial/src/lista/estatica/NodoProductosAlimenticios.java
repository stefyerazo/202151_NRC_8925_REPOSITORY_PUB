package lista.estatica;


public class NodoProductosAlimenticios {
	public ProductosAlimenticios dato;// Donde almaceno la estructura de datos
	public NodoProductosAlimenticios siguinte;// Puntero

	// Constructor inserta al final de la lista
	public NodoProductosAlimenticios (ProductosAlimenticios ndato) {
		this.dato = ndato;
		this.siguinte = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoProductosAlimenticios(ProductosAlimenticios palabras, NodoProductosAlimenticios nnodo) {
		this.dato = palabras;
		this.siguinte = nnodo;
	}
}
