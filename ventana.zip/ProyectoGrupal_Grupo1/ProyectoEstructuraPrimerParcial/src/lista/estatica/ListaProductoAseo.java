package lista.estatica;

import java.util.Scanner;

public class ListaProductoAseo {
	ListaProductoAseo[] listaAseo = new ListaProductoAseo [3];
	ListaProductoAseo oaseolista = null;
	protected NodoProductoAseo inicio, fin;// Puntero de la lista

	private String nombreProducto;
	private double costoProducto;
	private String categoria;
	private int idProductoAseo;
	private String descripcionAseo;
	
	/*public ListaProductoAseo() {
		this.nombreProducto = null;
		this.costoProducto = 0.0;
		this.categoria = null;
		this.idProductoAseo = 0;
		this.descripcionAseo = null;
	}*/
	int contador = 0;
	public ListaProductoAseo(String nombreProducto, double costoProducto, String categoria, int idProductoAseo,
			String descripcionAseo) {
		super();
		this.nombreProducto = nombreProducto;
		this.costoProducto = costoProducto;
		this.categoria = categoria;
		this.idProductoAseo = idProductoAseo;
		this.descripcionAseo = descripcionAseo;
	}
	
	public String getNombreProducto() {
		return nombreProducto;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}
	public double getCostoProducto() {
		return costoProducto;
	}
	public void setCostoProducto(double costoProducto) {
		this.costoProducto = costoProducto;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public int getIdProductoAseo() {
		return idProductoAseo;
	}
	public void setIdProductoAseo(int idProductoAseo) {
		this.idProductoAseo = idProductoAseo;
	}
	public String getDescripcionAseo() {
		return descripcionAseo;
	}
	public void setDescripcionAseo(String descripcionAseo) {
		this.descripcionAseo = descripcionAseo;
	}

	// Constructor
	public ListaProductoAseo() {
		this.inicio = null;
		this.fin = null;
	}

	// Metodo para agregar un nuevo nodo Inicio Lista
	public void agregarInicioProductoAseo(ProductoAseo palabras) {
		inicio = new NodoProductoAseo(palabras, inicio);
		// caso particular
		if (fin == null) {
			fin = inicio;
		}
	}

	// Metodo para mostrar los datos
	public void mostrarListaProductoAseo() {
		NodoProductoAseo recorrer = inicio;
		System.out.println();
		while (recorrer != null) {
			System.out.print("[" + recorrer.dato + "]-->");
			recorrer = recorrer.siguinte;
		}
		System.out.println("NULL");
	}
	
	public ProductoAseo eliminarInicioProductoAseo() {
		ProductoAseo elemento =inicio.dato;
		if (inicio==fin) {
			inicio=null;
			fin=null;
			//return 0;
		}else {
			inicio=inicio.siguinte;
		}
		return elemento;
	}
	
	public ProductoAseo eliminarFinalProductoAseo() {
		ProductoAseo elemento = fin.dato;
		if (inicio==fin) {
			inicio = null;
			fin = null;
		}else {
			NodoProductoAseo temporal=inicio;
			while(temporal.siguinte != fin) {
				temporal = temporal.siguinte;
				
			}
			fin=temporal;
			fin.siguinte =null;
		}
		return elemento;
	}
	
	public boolean estaVacia() {
		if (this.inicio ==null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void agregarFinal(ProductoAseo elemento) {
		//utilizar un metodo para verificar si esta vacia
		if (!estaVacia()) {
			this.fin.siguinte = new NodoProductoAseo(elemento);
			this.fin = fin.siguinte;
			
		}else {
			inicio = fin = new NodoProductoAseo(elemento);
			
		}
	}
	public ListaProductoAseo buscarPorNombre(String nombre) {
		
		if(!estaVacia()){
			for(int i = 0; i < listaAseo.length; i++) {
				if(listaAseo[i] != null) {
					if(listaAseo[i].getNombreProducto().equals(nombre)) {
						return listaAseo[i];
					}
				}
		}
			return null;
		}
		return null;
	}
	public void agregarProductoAseo(String nombreProducto, String categoria, int idProductoAseo, String descripcionAseo) {
		
		oaseolista = new ListaProductoAseo(nombreProducto, costoProducto, categoria, idProductoAseo, descripcionAseo);
		listaAseo[contador] = oaseolista;
		contador++;	
		
	}
	public void eliminarPorNombre(String nombre) {
		
		int indice = 0;
		
		if(buscarPorNombre(nombre) != null) {
			for(int i = 0; i < listaAseo.length; i++) {
				 if(listaAseo[i] != null) {
					 if(listaAseo[i].getNombreProducto().equals(nombre)) {
							indice = i;
					}
				 }
				 
			 }
			 System.arraycopy(listaAseo,indice+1,listaAseo,indice,listaAseo.length-1-indice);
			 System.out.println("Elemento eliminado");
			
		}else {
			System.out.println("Elemento no existe");
		}
	}
	public void mostrarLista() {
		for(int i = 0;  i < listaAseo.length; i++ ){
			if(listaAseo[i] != null){
				System.out.println( "Nombre: " +listaAseo[i].getNombreProducto()+ " ID: " +listaAseo[i].getIdProductoAseo()+ " Categoria " 
						+ listaAseo[i].getCategoria() + " Costo: "+listaAseo[i].getCostoProducto()+ " Descripcion: " + listaAseo[i].getDescripcionAseo() + "\n");
			}
			
		}
		
	}
	
	
	//String nombreProducto, double costoProducto, String categoria, int idProductoAseo, String descripcionAseo) {
	public void actualizarElemento(int n) {
		Scanner actu = new Scanner(System.in);
		System.out.println("Digite el nombre del producto: ");
		String nombreProducto = actu.next();
		System.out.println("Digite el costo del producto: ");
		double costoProducto = actu.nextDouble();
		System.out.println("Digite la categoria: ");
		String categoriaProducto = actu.next();
		System.out.println("Digite el ID del producto: ");
		int idProducto = actu.nextInt();
		System.out.println("Digite la descripcion: ");
		String descripcionProducto = actu.next();
		
		listaAseo[n-1].setNombreProducto(nombreProducto);
		listaAseo[n-1].setCostoProducto(costoProducto);
		listaAseo[n-1].setCategoria(categoriaProducto);
		listaAseo[n-1].setIdProductoAseo(idProducto);
		listaAseo[n-1].setDescripcionAseo(descripcionProducto);
	}
}
