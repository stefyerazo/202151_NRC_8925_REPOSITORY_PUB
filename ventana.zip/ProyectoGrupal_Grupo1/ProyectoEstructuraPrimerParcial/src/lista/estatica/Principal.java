package lista.estatica;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Principal {
	public static void main(String[] args) {
		ListaProductoAseo opaLista  = new ListaProductoAseo();
		ListaProductosAlimenticios opaliLista = new ListaProductosAlimenticios();
		ListaProductosVestimenta opvLista = new ListaProductosVestimenta();
		System.out.println("Software que permite ingresar productos al sistema de forma DINAMICA PARA 5");
		Scanner sc = new Scanner (System.in);
		int e1;
		int menu = 0;
		do {
			try {
		System.out.println("1.- Ingresar Productos de Aseo ");
		System.out.println("2.- Ingresar Productos Alimenticios");
		System.out.println("3.- Ingresar Productos de Vestimenta");
		System.out.println("3.- Salir");
		System.out.print("Su opcion es: ");
		menu = sc.nextInt();
		if(menu ==1) {
		System.out.print("Digite el nombre: ");
		String nombreAseo  = sc.next();
		System.out.print("Digite la categoria: ");
		String categoriaAseo = sc.next();
		System.out.print("Digite el ID del producto aseo: ");
		int idProductoAseo = sc.nextInt();
		System.out.print("Digite la descripcion: ");
		String  descripcion = sc.next();
		System.out.println("\n\t\tOPCIONES A REALIZAR");
		System.out.println("\n1.- Ingresar Producto");
		System.out.println("2.- Actualizar Producto");
		System.out.println("3.- Eliminar Producto ");
		System.out.println("4.- Mostrar Datos");
		//(String nombreProducto, double costoProducto, String categoria, int idProductoAseo,tring descripcionAseo) {
		System.out.print("Su opcion es: ");
		int menuCliente = sc.nextInt();
		switch (menuCliente) {
		case 1:
			try {
				System.out.println("Ingresar producto");
				opaLista.agregarProductoAseo(nombreAseo, categoriaAseo, idProductoAseo, descripcion);
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 2:
			try {
				System.out.println("Digite el ID del producto que quiere actualizar");
				e1 = sc.nextInt();
				opaLista.actualizarElemento(e1);
		
			
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 3:
			try {
				System.out.println("Digite el nombre del producto que quiere borrar");
				String nombreBorrar = sc.next();
				opaLista.eliminarPorNombre(nombreBorrar);
	
			} catch (NumberFormatException n) {
				JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
			}
			break;
		case 4:
			opaLista.mostrarLista();
			break;
			default: 
				System.out.println("ERROR!!!");
				
		/*else if(menu ==2) {
			
		}*/
		}
		
		} else if(menu==2) {
			//(int idProductoAlimenticio, String nombreAlimenticio, String categoriaAlimenticio, double precioAlimenticio) {
			System.out.print("Digite el ID del producto Alimenticio ");
			int idProAlimenticio  = sc.nextInt();
			System.out.print("Digite el nombre del producto ");
			String nombreAlimento = sc.next();
			System.out.print("Digite la categoria: ");
			String categoriaAlimento = sc.next();
			System.out.print("Digite el precio del alimento ");
			double precioAlimento = sc.nextDouble();
			System.out.println("\n\t\tOPCIONES A REALIZAR");
			System.out.println("\n1.- Ingresar Producto");
			System.out.println("2.- Actualizar Producto");
			System.out.println("3.- Eliminar Producto ");
			System.out.println("4.- Mostrar Datos");
			//(String nombreProducto, double costoProducto, String categoria, int idProductoAseo,tring descripcionAseo) {
			
			System.out.print("Su opcion es: ");
			int menuCliente = sc.nextInt();
			switch (menuCliente) {
			case 1:
				try {
					System.out.println("Ingresar producto");
					opaliLista.agregarProductosAlimenticios(idProAlimenticio, nombreAlimento, categoriaAlimento, precioAlimento);
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 2:
				try {
					System.out.println("Digite el ID del producto que quiere actualizar");
					e1 = sc.nextInt();
					opaliLista.actualizarElemento(e1);
			
				
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Digite el nombre del producto que quiere borrar");
					String nombreBorrar = sc.next();
					opaliLista.eliminarPorNombre(nombreBorrar);
		
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 4:
				opaLista.mostrarLista();
				break;
				default: 
					System.out.println("ERROR!!!");
			}
		}else if(menu==3) {
			// nombreVestimenta,  idVestimenta,  talla, String color, String categoria, double costoVestimenta) {
			System.out.print("Digite el nombre de la Vestimenta: ");
			String nombreVestimenta  = sc.next();
			System.out.print("Digite el ID de la Vestimenta ");
			int idVestimenta = sc.nextInt();
			System.out.print("Digite la Talla: ");
			String tallaVestimenta = sc.next();
			System.out.print("Digite el color de la Vestimenta: ");
			String colorVestimenta = sc.next();
			System.out.print("Digite la Categoria: ");
			String categoriaVestimenta = sc.next();
			System.out.print("Digite el costo de la Vestimenta: ");
			double  costoVestimenta = sc.nextDouble();
			System.out.println("\n\t\tOPCIONES A REALIZAR");
			System.out.println("\n1.- Ingresar Producto");
			System.out.println("2.- Actualizar Producto");
			System.out.println("3.- Eliminar Producto ");
			System.out.println("4.- Mostrar Datos");
			
			System.out.print("Su opcion es: ");
			int menuCliente = sc.nextInt();
			switch (menuCliente) {
			case 1:
				try {
					System.out.println("Ingresar producto");
					opvLista.agregarProductoVestimenta(nombreVestimenta, idVestimenta, tallaVestimenta, colorVestimenta, categoriaVestimenta, costoVestimenta);
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 2:
				try {
					System.out.println("Digite el ID del producto que quiere actualizar");
					e1 = sc.nextInt();
					opvLista.actualizarElemento(e1);
					
				
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Digite el nombre del producto que quiere borrar");
					String nombreBorrar = sc.next();
					opvLista.eliminarPorNombre(nombreBorrar);
		
				} catch (NumberFormatException n) {
					JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
				}
				break;
			case 4:
				opaLista.mostrarLista();
				break;
				default: 
					System.out.println("ERROR!!!");
			}
		}
			}catch (Exception e) {

		}

	} while (menu != 3);
	
	}
			
}
