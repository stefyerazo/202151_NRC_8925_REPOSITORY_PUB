package lista.estatica;

public class NodoProductoVestimenta {
	
	public ProductosVestimenta dato;// Donde almaceno la estructura de datos
	public NodoProductoVestimenta siguinte;// Puntero

	// Constructor inserta al final de la lista
	public NodoProductoVestimenta (ProductosVestimenta ndato) {
		this.dato = ndato;
		this.siguinte = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoProductoVestimenta(ProductosVestimenta palabras, NodoProductoVestimenta nnodo) {
		this.dato = palabras;
		this.siguinte = nnodo;
	}
}
