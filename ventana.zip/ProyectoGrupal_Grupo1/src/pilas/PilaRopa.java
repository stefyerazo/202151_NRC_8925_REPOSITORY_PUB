
package pilas;


public class PilaRopa {
    ProductosRopa vectorPila[];
    int cima;//dato
    
/*
      ------  PRODUCTOS LIMPIEZA -----
    */    

//Construtor Productos Limpieza
    public PilaRopa(int tamanio){
        vectorPila=new ProductosRopa[tamanio];
        cima=-1;
    }
    
    //PuSh Productos Limpieza
    public void push (ProductosRopa dato){
    this.cima++;
    vectorPila[cima]=dato;
    }
    
    //PopProductos Limpieza
    public ProductosRopa pop(){
    ProductosRopa salir=vectorPila[cima];
    cima--;
    return salir;
    }
    
    //Conocer que elemento se encuentra cima
    public ProductosRopa cimaPila(){
    return vectorPila[cima];
    }
    

/*
    MÉTODOS GENERALES
    */

//sabe si la pila esta vacia
    public boolean estaVacia(){
    return cima== -1;
    }

    
    //Tamaño pila
    public int tamanioPila(){
    return vectorPila.length;
    }
    
    public boolean estaLlena(){
    return vectorPila.length-1==cima;
    
    }
    
    //mostrar elementos
    public String mostrarElementos(){
        int cont = this.cima;
        String mostrar="..";
        for(int i=0;i<=cont;i++){
        mostrar="--> "+mostrar+vectorPila[i].toString()+".";
        }
       return mostrar;
    }
    
}
