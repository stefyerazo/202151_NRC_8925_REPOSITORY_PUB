package lista.estatica;


public class NodoProductoAseo {
	public ProductoAseo dato;// Donde almaceno la estructura de datos
	public NodoProductoAseo siguiente;// Puntero

	// Constructor inserta al final de la lista
	public NodoProductoAseo(ProductoAseo ndato) {
		this.dato = ndato;
		this.siguiente = null;
	}

	// Constructor para insertar al inicio de la lista
	public NodoProductoAseo(ProductoAseo palabras, NodoProductoAseo nnodo) {
		this.dato = palabras;
		this.siguiente = nnodo;
	}
}
