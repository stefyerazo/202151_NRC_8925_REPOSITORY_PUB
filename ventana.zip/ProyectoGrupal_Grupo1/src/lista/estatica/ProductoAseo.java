package lista.estatica;

public class ProductoAseo {
    
	private String nombreProducto;
	private double costoProducto;
	private int idProductoAseo;

	

	public ProductoAseo(String nombreProducto, double costoProducto, int idProductoAseo) {
		super();
		this.nombreProducto = nombreProducto;
		this.costoProducto = costoProducto;
		this.idProductoAseo = idProductoAseo;

	}
	
	public String getNombreProducto() {
		return nombreProducto;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}
	public double getCostoProducto() {
		return costoProducto;
	}
	public void setCostoProducto(double costoProducto) {
		this.costoProducto = costoProducto;
	}
	
	public int getIdProductoAseo() {
		return idProductoAseo;
	}
	public void setIdProductoAseo(int idProductoAseo) {
		this.idProductoAseo = idProductoAseo;
	}
	

	@Override
	public String toString() {
		return "ProductoAseo [nombreProducto=" + nombreProducto
                        +", idProductoAseo=" + idProductoAseo + "]";
	}

	
}
