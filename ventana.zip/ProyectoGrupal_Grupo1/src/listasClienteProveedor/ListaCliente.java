
package listasClienteProveedor;


public class ListaCliente {
  public NodoCliente inicio, fin;// Puntero de la lista

	// Constructor
	public ListaCliente() {
		this.inicio = null;
		this.fin = null;
	}

	// Metodo para agregar un nuevo nodo Inicio Lista
	public void agregarInicioCliente(Cliente palabras) {
		inicio = new NodoCliente(palabras, inicio);
		// caso particular
		if (fin == null) {
			fin = inicio;
		}
	}

	// Metodo para mostrar los datos
	public String mostrarListaCliente() {
		NodoCliente recorrer = inicio;
		String mostrar="";
                
                System.out.println();
		while (recorrer != null) {
			mostrar = mostrar+"[" + recorrer.dato + "]-->\n";
                        
			recorrer = recorrer.siguinte;
		}
		mostrar=mostrar+"null";
                return mostrar;
	}
	
	public Cliente eliminarInicioPersona() {
		Cliente elemento =inicio.dato;
		if (inicio==fin) {
			inicio=null;
			fin=null;
			//return 0;
		}else {
			inicio=inicio.siguinte;
		}
		return elemento;
	}
	
	public Cliente eliminarFinalPersona() {
		Cliente elemento = fin.dato;
		if (inicio==fin) {
			inicio = null;
			fin = null;
		}else {
			NodoCliente temporal=inicio;
			while(temporal.siguinte != fin) {
				temporal = temporal.siguinte;
				
			}
			fin=temporal;
			fin.siguinte =null;
		}
		return elemento;
	}
	
	public boolean estaVacia() {
		if (this.inicio ==null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void agregarFinal(Cliente elemento) {
		//utilizar un metodo para verificar si esta vacia
		if (!estaVacia()) {
			this.fin.siguinte = new NodoCliente(elemento);
			this.fin = fin.siguinte;
			
		}else {
			inicio = fin = new NodoCliente(elemento);
			
		}
	}  
}
