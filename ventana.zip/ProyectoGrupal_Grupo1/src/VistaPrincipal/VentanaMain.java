
package VistaPrincipal;


public class VentanaMain {
    public static void main(String[] args) {
            VentanaListaProductos ventana = new VentanaListaProductos();
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);
    }
    
}
